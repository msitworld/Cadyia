﻿using Cadyia.Data.Entities;

namespace Cadyia.Web.Contracts
{
    public interface IPlanRepository : IRepositoryBase<Plan>
    {
    }
}
