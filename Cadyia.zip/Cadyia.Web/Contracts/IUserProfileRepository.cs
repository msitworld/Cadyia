﻿using Cadyia.Data.Entities;

namespace Cadyia.Web.Contracts
{
    public interface IUserProfileRepository : IRepositoryBase<UserProfile>
    {
    }
}
